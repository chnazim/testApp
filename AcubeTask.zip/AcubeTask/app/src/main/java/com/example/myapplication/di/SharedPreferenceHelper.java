package com.example.myapplication.di;

import android.content.SharedPreferences;

public class SharedPreferenceHelper {

    private SharedPreferences pref;
    private SharedPreferences.Editor editor;

    private final String isLoggedIn = "loggedIn";
    private final String USER_NAME = "userName";
    private final String USER_TOKEN = "userToken";
    private final String ROLE_NAME = "roleName";


    public SharedPreferenceHelper(SharedPreferences pref, SharedPreferences.Editor editor) {
        this.pref = pref;
        this.editor = editor;
    }

    public void clearSharedPreference() {
        this.editor.clear();
        this.editor.apply();
    }


    public void setLoggedIn(boolean loggedIn) {
        editor.putBoolean(isLoggedIn, loggedIn).commit();
    }

    public boolean isLoggedIn() {
        return pref.getBoolean(isLoggedIn, false);
    }


    public void setUserName(String userName) {
        editor.putString(USER_NAME, userName).commit();
    }

    public String getUserName() {
        return pref.getString(USER_NAME, "");
    }

    public void setRoleName(String roleName) {
        editor.putString(ROLE_NAME, roleName).commit();
    }

    public String getRoleName() {
        return pref.getString(ROLE_NAME, "");
    }

    public void setUserToken(String userToken) {
        editor.putString(USER_TOKEN, userToken).commit();
    }

    public String getUserToken() {
        return pref.getString(USER_TOKEN, "");
    }

}