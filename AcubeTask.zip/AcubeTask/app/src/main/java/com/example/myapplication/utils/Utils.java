package com.example.myapplication.utils;

public class Utils {

    public static final String BASE_URL = "http://acuberfid.fortiddns.com:4480/lmsapi/lms/";


    public static final String COMPANY_ID = "HOST";
    public static final String APPLICATION_ID = "MOBILEAPP";
}
