package com.example.myapplication.di;


import android.content.Context;
import android.content.SharedPreferences;

import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;

@Module
public class SharedPreferenceModule {
    private SharedPreferences pref;
    private SharedPreferences.Editor editor;

    public SharedPreferenceModule(Context context) {
        String PREF_NAME = "com.example.app.testapp";
        int PRIVATE_MODE = 0;
        pref = context.getSharedPreferences(PREF_NAME, PRIVATE_MODE);
        editor = pref.edit();
        editor.apply();
    }

    @Provides
    @Singleton
    SharedPreferenceHelper provideSharedPreferenceHelper(){
        return new SharedPreferenceHelper(pref,editor);
    }
}
