package com.example.myapplication.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHandler extends SQLiteOpenHelper {

    private static final String DB_NAME = "appdb";
    private static final int DB_VERSION = 1;
    private static final String TABLE_NAME = "menu";
    private static final String ID_COL = "id";
    private static final String MENU_TYPE = "type";
    private static final String PARENT_MENU_NAME = "parent_name";
    private static final String MENU_NAME = "name";
    private static final String MENU_CONDITION = "condition";
    private static final String DISPLAY_NAME = "display_name";
    private static final String MENU_TEXT = "text";
    private static final String MENU_ICON_NAME = "icon_name";
    private static final String SORT_ORDER = "sort_order";
    private static final String COMPANY_ID = "company_id";
    private static final String MENU_ID = "menu_id";
    private static final String APP_MENU_ID = "app_menu_id";
    private static final String FIRST_SUB_MENU = "first_sub_menu";
    private static final String SECOND_SUB_MENU = "second_sub_menu";


    public DBHandler(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        String query = "CREATE TABLE " + TABLE_NAME + " ("
                + ID_COL + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + MENU_TYPE + " TEXT,"
                + PARENT_MENU_NAME + " TEXT,"
                + MENU_NAME + " TEXT,"
                + MENU_CONDITION + " TEXT,"
                + DISPLAY_NAME + " TEXT,"
                + MENU_TEXT + " TEXT,"
                + MENU_ICON_NAME + " TEXT,"
                + SORT_ORDER + " INTEGER,"
                + COMPANY_ID + " INTEGER,"
                + MENU_ID + " INTEGER,"
                + APP_MENU_ID + " INTEGER,"
                + FIRST_SUB_MENU + " TEXT,"
                + SECOND_SUB_MENU + " TEXT)";

        db.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    public void addMenu(String menuType, String parentName, String menuName, String menuCondition,
                        String displayNme, String menuText, String menuIconName, Integer sortOrder,
                        Integer companyId, Integer menuId, Integer appMenuId, String firstSubMenu,
                        String secondSubMenu) {


        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(MENU_TYPE, menuType);
        values.put(PARENT_MENU_NAME, parentName);
        values.put(MENU_NAME, menuName);
        values.put(MENU_CONDITION, menuCondition);
        values.put(DISPLAY_NAME, displayNme);
        values.put(MENU_TEXT, menuText);
        values.put(MENU_ICON_NAME, menuIconName);
        values.put(SORT_ORDER, sortOrder);
        values.put(COMPANY_ID, companyId);
        values.put(MENU_ID,menuId);
        values.put(APP_MENU_ID,appMenuId);
        values.put(FIRST_SUB_MENU,firstSubMenu);
        values.put(SECOND_SUB_MENU,secondSubMenu);


        db.insert(TABLE_NAME, null, values);
        db.close();

    }
}
