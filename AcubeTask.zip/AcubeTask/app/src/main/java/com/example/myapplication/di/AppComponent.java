package com.example.myapplication.di;


import com.example.myapplication.BaseActivity;

import javax.inject.Singleton;

import dagger.Component;

@Singleton
@Component(modules = {
        ApplicationModule.class,
        RetrofitModule.class,
        SharedPreferenceModule.class})

public interface AppComponent {

    void inject(BaseActivity baseActivity);

}
