package com.example.myapplication.di;

import com.example.myapplication.model.MenuModel;
import com.example.myapplication.model.UserLoginModel;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.POST;

public interface RetrofitInterface {

    /*USER LOGIN*/
    @FormUrlEncoded
    @POST("User/Authenticate")
    Call<UserLoginModel> userLogin(@Field("companyID") String companyId,
                                   @Field("applicationID") String applicationId,
                                   @Field("userName") String userName,
                                   @Field("password") String password);
    /*GET MENU*/
    @GET("AppRoleMenu/GetMenuDetails")
    Call<List<MenuModel>> getMenu(@Header("Authorization") String token);







}
