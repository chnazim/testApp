package com.example.myapplication;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.os.StrictMode;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.di.ApplicationClass;
import com.example.myapplication.di.RetrofitInterface;
import com.example.myapplication.di.SharedPreferenceHelper;

import javax.inject.Inject;

public class BaseActivity extends AppCompatActivity {

    @Inject
    public SharedPreferenceHelper sharedPreferenceHelper;

    @Inject
    public RetrofitInterface retrofitBuilder;

    ProgressDialog progressDialog;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ((ApplicationClass) BaseActivity.this.getApplication()).getNetComponent().inject(this);

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
    }

    public void showLoader() {
        progressDialog = new ProgressDialog(BaseActivity.this);
        progressDialog.setMessage("Loading...");
        progressDialog.setCancelable(false);
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.show();
    }

    public void hideLoader() {
        progressDialog.dismiss();
    }

    public void apiError(){
        Toast.makeText(this, "Api error", Toast.LENGTH_SHORT).show();
    }
}
