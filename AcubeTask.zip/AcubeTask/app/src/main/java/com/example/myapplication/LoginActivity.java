package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;

import com.example.myapplication.databinding.ActivityLoginBinding;
import com.example.myapplication.db.DBHandler;
import com.example.myapplication.model.MenuModel;
import com.example.myapplication.model.UserLoginModel;
import com.example.myapplication.utils.Utils;

import java.util.List;
import java.util.Objects;

import okhttp3.internal.Util;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends BaseActivity {

    ActivityLoginBinding binding;
    DBHandler dbHandler;
    List<MenuModel> menuModelList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_login);

        binding.loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (Objects.requireNonNull(binding.userName.getText()).toString().isEmpty()) {
                    binding.userName.setError("Enter your user Name");
                    binding.userName.requestFocus();
                } else if (Objects.requireNonNull(binding.password.getText()).toString().isEmpty()) {
                    binding.password.setError("Enter your password");
                    binding.password.requestFocus();
                } else {
                    showLoader();
                    callLoginApi(binding.userName.getText().toString(), binding.password.toString());
                }
            }
        });
    }

    private void callLoginApi(String userName, String password) {
        Call<UserLoginModel> call = retrofitBuilder.userLogin(Utils.COMPANY_ID, Utils.APPLICATION_ID, userName, password);
        call.enqueue(new Callback<UserLoginModel>() {
            @Override
            public void onResponse(Call<UserLoginModel> call, Response<UserLoginModel> response) {

                if (response.body() != null) {
                    sharedPreferenceHelper.setUserToken(response.body().getToken());
                    callApiForMenu(sharedPreferenceHelper.getUserToken());
                }


            }

            @Override
            public void onFailure(Call<UserLoginModel> call, Throwable t) {
                apiError();
                hideLoader();
                t.printStackTrace();
            }
        });
    }

    private void callApiForMenu(String userToken) {
        Call<List<MenuModel>> call = retrofitBuilder.getMenu(userToken);
        call.enqueue(new Callback<List<MenuModel>>() {
            @Override
            public void onResponse(Call<List<MenuModel>> call, Response<List<MenuModel>> response) {
                if (response.body() != null) {
                    menuModelList = response.body();
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            addDataToDb(menuModelList);
                        }
                    }, 500);
                }
            }

            @Override
            public void onFailure(Call<List<MenuModel>> call, Throwable t) {

            }
        });
    }

    private void addDataToDb(List<MenuModel> menuModelList) {
        for (int i = 0; i < menuModelList.size(); i++) {
            dbHandler.addMenu(menuModelList.get(i).getMenuType(), menuModelList.get(i).getParentMenuName(),
                    menuModelList.get(i).getMenuName(), menuModelList.get(i).getMenuCondition(),
                    menuModelList.get(i).getDisplayName(), menuModelList.get(i).getMenuText(),
                    menuModelList.get(i).getMenuIconName(),menuModelList.get(i).getSortOrder(),
                    menuModelList.get(i).getCompanyID(),menuModelList.get(i).getMenuID(),
                    menuModelList.get(i).getAppMenuID(),menuModelList.get(i).getFirstSubMenu(),
                    menuModelList.get(i).getSecondSubMenu());
        }

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                hideLoader();
                startActivity(new Intent(getApplicationContext(),MainActivity.class));
                finish();

            }
        },8000);
    }
}