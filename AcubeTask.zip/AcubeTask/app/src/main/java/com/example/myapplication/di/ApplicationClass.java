package com.example.myapplication.di;



import static com.example.myapplication.utils.Utils.BASE_URL;

import android.app.Application;


public class ApplicationClass extends Application {
    private AppComponent mNetComponent;


    @Override
    public void onCreate() {
        super.onCreate();
        mNetComponent = DaggerAppComponent.builder()
                .sharedPreferenceModule(new SharedPreferenceModule(this))
                .retrofitModule(new RetrofitModule(BASE_URL))
                .build();
    }

    public AppComponent getNetComponent() {
        return mNetComponent;
    }

}
