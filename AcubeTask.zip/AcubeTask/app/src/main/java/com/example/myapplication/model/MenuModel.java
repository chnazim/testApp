package com.example.myapplication.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class MenuModel {

    @SerializedName("menuType")
    @Expose
    private String menuType;
    @SerializedName("parentMenuName")
    @Expose
    private String parentMenuName;
    @SerializedName("menuName")
    @Expose
    private String menuName;
    @SerializedName("menuCondition")
    @Expose
    private String menuCondition;
    @SerializedName("displayName")
    @Expose
    private String displayName;
    @SerializedName("menuText")
    @Expose
    private String menuText;
    @SerializedName("menuIconName")
    @Expose
    private String menuIconName;
    @SerializedName("sortOrder")
    @Expose
    private Integer sortOrder;
    @SerializedName("companyID")
    @Expose
    private Integer companyID;
    @SerializedName("menuID")
    @Expose
    private Integer menuID;
    @SerializedName("appMenuID")
    @Expose
    private Integer appMenuID;
    @SerializedName("firstSubMenu")
    @Expose
    private String firstSubMenu;
    @SerializedName("secondSubMenu")
    @Expose
    private String  secondSubMenu;

    public String getMenuType() {
        return menuType;
    }

    public void setMenuType(String menuType) {
        this.menuType = menuType;
    }

    public String getParentMenuName() {
        return parentMenuName;
    }

    public void setParentMenuName(String parentMenuName) {
        this.parentMenuName = parentMenuName;
    }

    public String getMenuName() {
        return menuName;
    }

    public void setMenuName(String menuName) {
        this.menuName = menuName;
    }

    public String getMenuCondition() {
        return menuCondition;
    }

    public void setMenuCondition(String menuCondition) {
        this.menuCondition = menuCondition;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public String getMenuText() {
        return menuText;
    }

    public void setMenuText(String menuText) {
        this.menuText = menuText;
    }

    public String getMenuIconName() {
        return menuIconName;
    }

    public void setMenuIconName(String menuIconName) {
        this.menuIconName = menuIconName;
    }

    public Integer getSortOrder() {
        return sortOrder;
    }

    public void setSortOrder(Integer sortOrder) {
        this.sortOrder = sortOrder;
    }

    public Integer getCompanyID() {
        return companyID;
    }

    public void setCompanyID(Integer companyID) {
        this.companyID = companyID;
    }

    public Integer getMenuID() {
        return menuID;
    }

    public void setMenuID(Integer menuID) {
        this.menuID = menuID;
    }

    public Integer getAppMenuID() {
        return appMenuID;
    }

    public void setAppMenuID(Integer appMenuID) {
        this.appMenuID = appMenuID;
    }

    public String getFirstSubMenu() {
        return firstSubMenu;
    }

    public void setFirstSubMenu(String firstSubMenu) {
        this.firstSubMenu = firstSubMenu;
    }

    public String getSecondSubMenu() {
        return secondSubMenu;
    }

    public void setSecondSubMenu(String secondSubMenu) {
        this.secondSubMenu = secondSubMenu;
    }

}
